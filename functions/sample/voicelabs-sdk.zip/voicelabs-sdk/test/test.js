var VoiceInsights = require('voice-insights-sdk');

VoiceInsights.initialize({'user':{'userId': 'fooappuserid-1234'},'sessionId' : 'app-rocks-session-id-2', 'new':true},'b5542bdd-1723-3c2b-a590-b82368bce8a1');

VoiceInsights.track("EndSession", null, "<speak>This is what we want Alexa to say. <p>Bla</p></speak>");
