var Enums = {
  eventTypes: {
    INITIALIZE: 'INITIALIZE',
    SPEECH: 'SPEECH',
  }
}

module.exports = Enums;
