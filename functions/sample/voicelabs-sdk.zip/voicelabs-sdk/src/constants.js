var Constants = {
  /**
   * API Config
   * @type {Object}
   */
  api: {
    baseAdvertisingURL: 'https://advertising.voicelabs.co/',
    baseAnalyticsURL: 'https://api.voicelabs.co/',
    eventsAPI: 'events/',
    adsAPI: 'adevents/',
  },

  state: {
    AD_STATE : 'VOICELABS_AD_STATE',
  },

  defaultAudioMiss: {
      url: 'https://s3.amazonaws.com/voicelabs-ads/audiobit-48.mp3',
      audio: '<audio src="https://s3.amazonaws.com/voicelabs-ads/audiobit-48.mp3" />',
      ssml: '<speak><audio src="https://s3.amazonaws.com/voicelabs-ads/audiobit-48.mp3"></speak>'
  },

  /**
   * Returns a formatted authentication URL
   * @param  {String} baseUrl String containing the API base URL
   * @param  {String} token   String containing the unique app token
   * @return {String}         String formatted with auth URL
   */
  authURL: function(baseUrl, token){
    var query = 'auth_token=' + token;

    return (baseUrl + '&' + query).replace(/[&?]{1,2}/, '?');
  }
};

module.exports = Constants;
