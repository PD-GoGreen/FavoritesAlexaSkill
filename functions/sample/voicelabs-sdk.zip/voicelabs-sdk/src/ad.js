var Request = require('request-promise'),
    BPromise = require('bluebird'),
    Constants = require('./constants'),
    _ = require('./utils');

/**
 * VoiceEvent constructor
 * @constructor
 * @param  {String} name String containing the event name (ex: INITIALIZE, SESSION_START, etc...)
 * @param  {Object} data Object containing metadata for the event
 * @return {Void}
 */
var AdCall = function(params){
  this.appToken = params.token;
  this.adUnitId = params.adUnitId;
  this.sessionId = params.sessionId;
  this.userId = params.userId;
  this.interaction = params.interaction;
}

_.extend(AdCall.prototype, {
  /**
   * Post action to events API endpoint
   * @param  {Function} callbackFn Callback to execute on request successful completion
   * @return {Void}
   */
  fill: function(callbackFn){

    var URL = Constants.authURL(Constants.api.baseAdvertisingURL + Constants.api.adsAPI, this.appToken);

    return BPromise.resolve(Request.post(URL, {
        timeout: 1500,
        json: {
          adUnitId: this.adUnitId,
          sessionId:this.sessionId,
          userId:this.userId,
          appToken: this.appToken,
          interaction: this.interaction
        },
        resolveWithFullResponse: true
      })).then(function(response) {

        var status = response ? response.statusCode : 500,
            output = {
              status: status
            };

        if(status >= 200 && status < 300 || status === 304){
          output = response.body;
          return output;
        }else{
          return Constants.defaultAudioMiss
        }

    }).catch(function(error){
      return Constants.defaultAudioMiss;
    })
    .asCallback(callbackFn);
  },

});

module.exports = AdCall;
