var AdCall = require('./ad'),
    Event = require('./event'),
    Enums = require('./enums'),
    md5 = require('MD5'),
    Alexa = require("alexa-sdk"),
    BPromise = require('bluebird'),
    constants = require('./constants'),
    _ = require('./utils'),
    /**
     * Error messages
     * @type {Object}
     */
    errors = {
      exception: '[VoiceLabs ERROR] Unexpected Exception',
      noTokenError: '[VoiceLabs ERROR]: You must initialize with a valid token before tracking.',
      invalidSessionError: '[VoiceLabs ERROR]: You must provide a valid session object.',
      invalidSessionId: '[VoiceLabs ERROR]: You must provide a valid session ID.',
      invalidInputsError: '[VoiceLabs ERROR] Invalid inputs object passed through request.',
      invalidUserError: '[VoiceLabs ERROR]: A valid user ID must be provided, got null',
      invalidConversationError: '[VoiceLabs ERROR] Invalid conversation object passed through request.',
      invalidIntentNameError: '[VoiceLabs ERROR] Invalid intentName passed through.',
      invalidAdUnitError: '[VoiceLabs ERROR] A valid ad unit ID is required, create ad unit first',
      noCallbackError: 'A valid callbackFn is required',
    },
    /**
     * Session event and payload data
     * @type {Object}
     */
    config = {};

/**
 * VoiceLabs reference
 * @param  {String} token   String containing the unique app token
 * @return {Void}
 */
var VoiceLabs = function(token){

  if(!token || token && !token.length || token && !_.isString(token)){
    console.error(errors.noTokenError);
  }

  config.appToken = token;

  return VoiceLabs;
};

_.extend(VoiceLabs, {
  /**
   * Fires the initialize event and executes the callback
   * @param  {Object} session Object containing session data
   * @param  {String} token   String containing the unique app token
   * @return {Void}
   */
  initialize: function(token){
    return VoiceLabs(token);
  },

  /**
   * Fires the track event and executes the callback
   * function with the speech output SSML + response
   * @param  {Object}   session               Alexa Session Object (to get userId and SessionId)
   * @param  {String}   intentName            The intent string
   * @param  {Object}   intentMetadata        (Optional) Object containing intent metadata like slots
   * @param  {String}   speechText            (Optional) String speech out by Alexa
   * @param  {Function} cb                    (optional) Callback function for success, always gets called
   * @return {Promise}
   */
  track: function(session, intentName, intentMetadata, speechText, cb){

    try {
      var error = false,
          userId = null,
          sessionId = null;

      //Error check to make sure we have everything we need
      if(!config.appToken || !config.appToken.length || !_.isString(config.appToken)){
        console.error(errors.noTokenError);
        error = true;
      }

      if(!_.isObject(session)){
        console.error(errors.invalidSessionError);
        error = true;
      }

      if(!session || !session.sessionId){
        console.error(errors.invalidSessionId);
        error = true;
      }

      if(!session.user || !session.user.userId){
        console.error(errors.invalidUserError);
        error = true;
      }else{
        uid = md5(session.user.userId);
      }

      if(!intentName) {
        console.error(errors.invalidIntentNameError);
        error = true;
      }

      if(error){
        //return promise, and always issue callback in .then() for convenience
        return BPromise.resolve({
          error: 'Invalid arguments passed to track(). See standard error for details.'
        }).asCallback(cb);
      }

      sessionId = session.sessionId;
      userId = uid;

      var payload = {
        app_token: config.appToken,
        user_hashed_id: userId,
        session_id: sessionId,
        intent: intentName,
        data: {
          metadata: intentMetadata,
          speech: speechText,
        },
      };

      var event = new Event(Enums.eventTypes.SPEECH, payload);

      //return promise, and always issue callback
      return BPromise
        .resolve(event.send())
        .catch(function(error){
          console.error(errors.exception, error);
        })
        .asCallback(cb);

    } catch(err){
      //Full safeguard to ensure we always return
      return BPromise.resolve({
        error: err
      }).asCallback(cb);
    }

  },

  /**
   * gets an ad to deliver to the user and executes the callback
   * @param  {String}   adUnitId              Unique ID for this ad unit slot
   * @param  {String}   session               Valid session object from Alexa
   * @param  {Object}   handler               [Optional] Object for interactive ad only
   * @param  {Function} callbackFn            Callback function for success
   * @return {Void}
   */
  deliverAd: function(adUnitId, session, handler, callbackFn) {
    var userId = null,
        sessionId = null,
        error = null;

    //session requirements
    if(!_.isObject(session)){
      console.error(errors.noTokenError);
      error = errors.noTokenError;
    }

    if(!session || !session.sessionId){
      console.log(errors.invalidSessionId);
      error = errors.invalidSessionId;
    } else {
      sessionId = session.sessionId;
    }

    if(!session.user || !session.user.userId){
      console.log(errors.invalidUserError);
      error = errors.invalidUserError;
    }else{
      userId = md5(session.user.userId);
    }

    //adUnitId requirements
    if(!adUnitId){
      console.log(errors.invalidAdUnitError);
      error = error.invalidAdUnitError;
    }

    //callback & handler requirements
    if(callbackFn === undefined && handler === undefined){
      console.log(errors.noCallbackError);
      error = errors.noCallbackError
    } else if(callbackFn === undefined && handler !== undefined){
      //non-interactive ad call, swap handler with callbackFn
      callbackFn = handler;
      handler = null;
    }

    if(error){
      if(_.isFunction(callbackFn)){
        callbackFn({
          error: 'Invalid arguments passed to track(). See standard error for details.'
        });
      }
      return;
    }

    //interactive ad call
    if(handler && callbackFn) {
      //set handler state to transition into interactive ad
      handler.state = constants.state.AD_STATE;
    }

    var adCall = new AdCall({
      token: config.appToken,
      adUnitId: adUnitId,
      sessionId: sessionId,
      userId: userId
    });

    adCall.fill(callbackFn);
  },

  getAdHandler: function(){

    return Alexa.CreateStateHandler(constants.state.AD_STATE, {

      'AMAZON.YesIntent': function() {

          var adCall = new AdCall({
            token: config.appToken,
            sessionId: this.event.session.sessionId,
            userId: md5(this.event.session.user.userId),
            interaction: 'YES'
          });

          adCall.fill((error, ad) => {
              this.emit(':tell', ad.audio);
          });

      },

      'AMAZON.NoIntent': function() {
        var adCall = new AdCall({
          token: config.appToken,
          sessionId: this.event.session.sessionId,
          userId: md5(this.event.session.user.userId),
          interaction: 'NO'
        });

        adCall.fill((error, ad) => {
            this.emit(':tell', ad.audio);
        });
      },

      'Unhandled': function() {
        var adCall = new AdCall({
          token: config.appToken,
          sessionId: this.event.session.sessionId,
          userId: md5(this.event.session.user.userId),
          interaction: 'NO'
        });

        adCall.fill((error, ad) => {
            this.emit(':tell', ad.audio);
        });
      }

    });
  },
});

module.exports = VoiceLabs;
