var VoiceLabs = require('./core');

global.VoiceLabs = function(token){
  VoiceLabs.initialize(token);
};

module.exports = VoiceLabs;
